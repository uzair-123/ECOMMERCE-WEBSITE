<!DOCTYPE html>
<html>
<body>

<?php
$str = "Hello World!";
echo $str . "<br>";
echo trim($str,"Hel!");
?>

</body>
</html>